temperatures = [28,34,44,38,49]
highest_temp = max(temperatures)
lowest_temp = min(temperatures)
print(f"Highest temperatures in a week:{highest_temp}°c")
print(f"lowest temperatures in a week:{lowest_temp}°c")
print(f"weekly temperatures:{temperatures}°c")

path = ("A","B","C","D")
return_path = path[::-1]
print("orginal path",path)
print("return path,",return_path)

fib_sequence = [0,1]
while len(fib_sequence) < 15:
    next_number = fib_sequence[-1] + fib_sequence[-2]
    fib_sequence.append(next_number)
fib_tuple = tuple(fib_sequence)
print(fib_sequence)

a = 10
b = 20
print(f"before swaping a = {a}, b = {b}")
temp = a
a = b
b = a
print(f"after swaping a = {a}, b = {b}")