set = {1,2,3,5,5,4,6,6}
print(set)


set = {1,2,3,5,5,4,6,6}
set.add(7)
print(set)



set = {1,2,3,5,5,4,6,6}
set.remove(6)
print(set)



set = {1,2,3,5,5,4,6,6}
set.clear()
print(set)



set = {1,2,3,5,5,4,6,6}
set.pop()
print(set) 



set = {1,2,3,5,5,4,6,6}
set.discard(5)
print(set)


list = [1,2,3,4,4,5,6,7,8,9]
list1 = []
for i in list:
    if i not in list1:
        list1.append(i)
print(list1)


##union set
set1 = {1,2,3,4,5}
set2 = {4,5,6,7,8}
union_set = set1 | set2
print(union_set)

##intersection set
set1 = {1,2,3,4,5}
set2 = {4,5,6,7,8}
intersection_set = set1 & set2
print(intersection_set)

##number_set
set1 = {1,2,3,4,5}
set2 = {4,5,6,7,8}
number_set = set1 ^ set2
print(number_set)


##update set
set1 = {1,2,3,4,5}
set2 = {4,5,6,7,8}
set1.update(set2)
print(set1)



##difference set
set1 = {1,2,3,4,5} 
set2 = {4,5,6,7,8}
difference_set = set1 - set2
print(difference_set)


##updatr (set list or tuple)
fruits = {'apple', 'banana'}
more_fruits = ['cherry', 'orange','apple']
fruits.update(more_fruits)
print(f"set after update: {fruits}")


##discard()
tech = {'python', 'java', 'c++'}
tech.discard('java')
print(f"after discarding 'java': {tech}")
tech.discard('go')
print(f"after discarding 'go': {tech}")






