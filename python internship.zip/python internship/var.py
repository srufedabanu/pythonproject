a = 10
print(a)

name = input("enter the name:")
print(f"name of the student is:{name}")

branch = input("enter branch name:")
print(f"name of the branch is:{branch}")

regno = input("enter the reg no:")
print(f"the student reg no is:{regno}")

usn = input("enter the usn no:")
print(f"student usn is:{usn}")

