# creating class
class student:
    name = "Ayesha Siddiqa"
    
#creating object(instance of class)
s1 = student()
print(s1.name)
    
    

##methods
class student:
    def __init__(self,fullname):
        self.name = fullname
    def hello(self):
        print("hello",self.name)
s1 = student("ayesha")
print(s1.name)

##
class person:
    def __init__(self,name,age):
        self.name = name
        self.age = age
        
    def say_hello(self):
        print("Hello, my name is", self.name, "and I am",self.age,"years old.")
        
p1= person("hanzala",10)
p2 = person("umer",15)

p1.say_hello()
p2.say_hello()

#init functions
class student:
    def __init__(self,fullname):
        self.name = fullname
s1 = student("ayesha")
print(s1.name)


#without parameter
class Animal:
    def sound(self):
        print("This animal make a sound.")
        
a=Animal()
a.sound()


#without self parameter
class mathopertions:
    @staticmethod
    def add(a,b):
        return a + b
result = mathopertions.add(3,7)
print("sum:",result)

class Greeting:
    @staticmethod
    def say_hello():
        print("Hello, python!")
Greeting.say_hello()


class Student:
    def __init__(self,name):
        self.name = name
        
    def show_name(self):
        print("Student Name is",self.name)
    
s1= Student("bisket")
s2 = Student("bushra")
s3 = Student("faiza")
s4 = Student("rushda")

s1.show_name()
s2.show_name()
s3.show_name()
s4.show_name()

class Animal:
    def __init__(self,name,color):
        self.name = name
        self.color = color
        
    def sound(self):
        print(f"{self.color},{self.name} make a sound.")
a1 = Animal("cow","black")
a2 = Animal("cat","red")
a3 = Animal("dog","white")

a1.sound()
a2.sound()
a3.sound()

print(a1)
print(a2)
print(a3)


#define a rectangle class with length and width attributes.create two methods calculate_area()to return the area and calculate_perimeter(0 to return the perimeter of the rectangle
class Rectangle:
    def __init__(self,length,width):
        self.length = length
        self.width = width
        
    def calculate_area(self):
        return self.length * self.width
    
    def calculate_perimeter(self):
        return 2 *(self.length+self.width)

rect = Rectangle(5,3)
print("Area:", rect.calculate_area())
print("Perimeter:",rect.calculate_perimeter())



#create a banck account class with a balnce attribute.implement deposit() and withdraw(0methods the withdrawal should not be allowed if the amount is greather than the current balance also include  get_balnce() method
class BankAccount:
    def __init__(self,initial_balance=0):
        self.balance = initial_balance
        
    def deposite(self,amount):
        if amount > 0 :
            self.balance += amount
            print(f"Deposite:{amount}")
        else:
            print("Deposite amount must be positive.")
            
    def withdraw(self,amount):
        if amount > self.balance:
             print("Withdrawal denied: insufficient funds.")
        elif amount <= 0:
            print("Withdraw amount must be positive.")
            
            
    def get_balance(self):
        return self.balance
account = BankAccount(100)
account.deposite(50)
account.withdraw(30)
account.withdraw(150)
print("Current balance:",account.get_balance())



#design a car class with make and model attributes along with a boolean attribute is_engine_on. create start_engine()and stop_engine()methods that change the is_engine_on state and print a status message
class Car:
    def __init__(self,make,model):
        self.make = make
        self.model = model
        self.is_engine_on = False
    def start_engine(self):
        if not self.is_engine_on:
            self.is_engine_on = True
            print(f"The engine of the {self.make} {self.model} is now ON. ")
        else:
            print(f"The engine of the {self.make} {self.model} is already ON.")   
    def end_engine(self):
        if self.is_engine_on:
            self.is_engine_on = False
            print(f"The engine of the {self.make} {self.model} is now OFF.")
        else:
            print(f"The engine of the {self.make} {self.model} is already OFF.")
my_car = Car("Toyota","corolla")
my_car.start_engine()
my_car.start_engine()
my_car.end_engine()
my_car.end_engine()
   
   
#create a book class with title and author attribute write a method get_details () that returns a string in the formate "title:[title], author:[author]
class Book:
    def __init__(self,title,author):
        self.title = title
        self.author = author
            
    def get_details(self):
        return f"title: {self.title}, author: {self.author}"
book = Book("1980","java")
print(book.get_details())


    
class Product:
    def __init__(self,name,price,quantity):
        self.name = name
        self.price = price
        self.quantity = quantity
        
    def calculate_total_value(self):
        return self.price * self.quantity

product = Product("loptop",30000,5)
print("Total value of stack:",product.calculate_total_value())

class Employee:
    total_employees = 0
    def __init__(self,name):
        self.name = name
        Employee.total_employees += 1
emp1 = Employee("Rehman")
emp2 = Employee("Mousa")
emp3 = Employee("Maaz")
print(f"Total number of employees: {Employee.total_employees}")

city = "Bengaluru"
print(f"Before deletion:{city}")
del city
print("The variable 'city' has been deleted")

        
class MYclass:
    def say_hello(self):
        print("Hello!")
def use_object(obj):
        obj.say_hello()
obj = MYclass()
use_object(obj)
del obj

class calculator:
    @staticmethod
    def add(x,y):
        return x + y
    @staticmethod
    def multiply(x ,y):
        return x * y
sum_result = calculator.add(15,8)
print(f"calling on the class: 15 + 8 ={sum_result}")

product_result = calculator.multiply(4,8)
print(f"caling on the class: 4 * 8 = {product_result} ")
my_calc_instance = calculator()
instance_sum = my_calc_instance.add(100,200)
print(f"calling on an instance: 100 + 200 = {instance_sum}")
        
        
import string
import secrets
def generate_password(length=12):
    if length < 4:
        raise ValueError("Password length should be at least 4 characters.")
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    symbols = string.punctuation
    password = [
        secrets.choice(lowercase),
        secrets.choice(uppercase),
        secrets.choice(digits),
        secrets.choice(symbols),
    ]
    all_chars = lowercase + uppercase + digits + symbols
    password += [secrets.choice(all_chars) for _ in range(length - 4)]
    secrets.SystemRandom().shuffle(password)
    return ''.join(password)
print("Generated password:", generate_password(16))

import random
import string
def generate_password(length=12):
    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(random.choice(characters) for _ in range(length))
    return password
print("Generated Password:", generate_password(12))
        