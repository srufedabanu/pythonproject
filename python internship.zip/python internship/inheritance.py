#single Inheritance
class Animal:
    def speak(self):
        print("Animal speak")
class Dog(Animal):
    def speck(self):
        print("Dog barks")
d = Dog()
d.speck()

#parent class
class Vehicle:
    def start_engine(self):
        print("Engine started.")
#child class inheritance from vehicle
class Car(Vehicle):
    def drive(self):
        print("Car is driving.")
#create an object of the child class
my_car = Car()
my_car.start_engine()
my_car.drive()


class Person:
    def __init__(self, id,name,location):
        self.id = id
        self.name = name
        self.location = location
    def display(self):
        print(f"ID: {self.id}")
        print(f"Name: {self.name}")
        print(f"Location : {self.location}")
class Employee(Person):
    def __init__(self,id,name,location,employee_id,department):
        super().__init__(id,name,location)
        self.employee_id = employee_id
        self.department = department
    
    def display(self):
        super().display()
        print(f"Employee_id : {self.employee_id}")
        print(f"Department : {self.department}")
emp = Employee(1,"Hanzala","Cowl Bazar","E101","CSE")
emp.display()

class Family:
    def __init__(self,family_name,address):
        self.family_name = family_name
        self.address = address
    def show_family_info(self):
        print(f"Family Name: {self.family_name}")
        print(f"Address: {self.address}")
class Child(Family):
    def __init__(self, family_name, address,child_name,age):
        super().__init__(family_name, address)
        self.child_name = child_name
        self.age = age
    def show_child_info(self):
        print(f"Child Name: {self.child_name}")
        print(f"Age: {self.age}")
child = Child("Shaik","Ballari","Hanzala",10)
child.show_family_info()
child.show_child_info()