for num  in range(1,11):
    if num % 2 != 0:
        continue
    print(num)
    
for num in range(1,11):
    if num % 2 !=0:
        continue
    print(f"Found an even number:{num}")
print("loop has finished.")

text = [86,64,33,95,76]
part1 = text[1:4]
part2 = text[:4]
part3 = text[1:]
part4 = text[2:4:1]


print(part1)
print(part2)
print(part3)
print(part4)
