def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
arr = [64, 34, 25, 12, 22, 11, 90]
bubble_sort(arr)
print("Sorted array is:",arr)


def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0,n-i-1):
            print(f"Comparing {arr[j]} and {arr[j+1]}")
            if arr[j] > arr[j+1]:
                print(f"Swap {arr[j]} and {arr[j+1]}")
                arr[j], arr[j + 1] = arr[j+1], arr[j]
                print(f"Array after swap: {arr}")
            else:
                print("No swap needed")
        print(f"end of pass{i+1}:{arr}")
    print(f"Final sorted array:",arr)
bubble_sort([5,4,2,1])

nested_list = [
    [34,12,25,9,50,1]
]
def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j],arr[j+1] = arr[j+1],arr[j]
print("Original nested list:", nested_list)
bubble_sort(nested_list[0])
print("Sorted nested list:", nested_list)
