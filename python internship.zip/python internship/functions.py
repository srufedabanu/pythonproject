def sum(a,b):
    s = a + b
    return s
print(sum(5,4))

def greet(name):
    return f"Hello,{name}!"
print(greet("Ayesha"))


# default parameters
def cal_prod(a=4, b=2):
    print(a * b)
    return a * b
cal_prod()

def cal_prod(a, b=2):
    print(a * b)
    return a * b
cal_prod(5)

#functions without Parameter

def show_welocme_message():
    print("Welocome to the App!")
show_welocme_message()
    
    
def greet_user(user_name):
    print(f"Hello,{user_name}!Its great to see you.")
greet_user("Ayesha")
greet_user("Hanzala")

def greet_user(user_name):
    print(f"Hello,{user_name}!Welcome back.")
greet_user("Ayesh")
current_user = "Umema"
greet_user(current_user)

def student_info(name , roll_no, branch):
    print("Name:", name)
    print("Roll Number:", roll_no)
    print("Branch:", branch)  
student_info("ummema", 101, "Computer Science")
student_info("Zimmam", 102, "Electrical Enggneering")  

#length

def print_list_length(my_list):
    length = len(my_list)
    print("length of the list :",length)
simple_list = [10,20,30,40,50]
print_list_length(simple_list)

def print_natural_numbers():
    for i in range(1,11):
        print(i)
print_natural_numbers()

def check_even_odd(number):
    if number % 2 == 0:
        print(f"{number} is even.")
    else:
        print(f"{number} is odd.")
check_even_odd(7)
check_even_odd(8)
    
    
def usd_to_inr(usd_amount):
    exchange_rate = 87.76
    inr_amount = usd_amount * exchange_rate
    return inr_amount
usd = float(input("Enter amount in usd:"))
inr = usd_to_inr(usd)
print(f"{usd} USD is approximately {inr:.2f} INR")

def reverse_string(s):
    return s[::-1]
input_str = "Hello"
reversed_str = reverse_string(input_str)
print(reversed_str)

def reverse_string(s):
    reversed_str = ""
    for char in s :
        reversed_str = char + reversed_str
    return reversed_str
input_str = "hello"
reversed_str = reverse_string(input_str)
print(reversed_str)


#given string is palidrome or not give code in functions
def is_palindrome(s):
    s = s.lower()
    return s == s[::-1]
input_str = "hello"
if is_palindrome(input_str):
    print(f"{input_str} is a palindrome")
else:
    print(f"{input_str} is not a palindrome")
    
#write a function count vowels that counts the number of vowels(a e i o u)in a given string the count should be case insensitive
def count_vowels(s):
    vowels = "aeiou"
    count = 0
    s = s.lower()
    for char in s:
        if char in vowels:
            count += 1
    return count
input_str = "Hello Python"
print(f"number of vowels:", count_vowels(input_str))


#give code for lower and upper letters in string using built in functions
def count_lower_upper(s):
    lower_count = 0
    upper_count = 0
    for char in s:
        if char.islower():
            lower_count  +=1
        elif char.isupper():
            upper_count +=1
    return lower_count, upper_count  
input_str = "Welcome Python"
lower , upper = count_lower_upper(input_str)
print(f"lower letter:{lower}")
print(f"upper letter:{upper}")

#write a function find_max that takes a list of numbers and returns the largest number in the list

def find_max(numbers):
    if not numbers:
        return None
    max_num = numbers[0]
    for num in numbers:
        if num > max_num:
            max_num = num
    return max_num
nums = [1,3,5,7,9]
print("Largest number is:", find_max(nums))


#write a function  without max that takes a list of numbers and returns the largest number in the list
def find_max(numbers):
    if not numbers:
        return None
    largest = numbers[0]
    for num in numbers:
        if num > largest:
            largest = num
    return largest

nums = [2,4,5,6,8,7,8]
print("largest number is:",find_max(nums))
    
    
def remove_duplicates(list):
    seen = set()
    result = []
    for item in list:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result
input_str = [1,2,2,3,4,5,6,4,6,5,4,3]
print(remove_duplicates(input_str))
            
        
        
#write a function factorial that calculates the factorial of a non negative integer using     
def factorial(n):
    if n < 0 :
        raise ValueError("Factorial is not define for negative numbers")
    if n == 0 or n == 1:
        return 1
    return n*factorial(n -1)
print(factorial(5))


###create a function celsius_to_fahrenheit that converts a temperature from celsius to fahrenheit. the formula is $f=(c\*9/5)+32$
def celsius_to_fahrenheit(c):
    return (c * 9/5) + 32
        
print(celsius_to_fahrenheit(0))
print(celsius_to_fahrenheit(100))


def greet_user(username,hour):
    if not (0 <= hour <=23):
        print("Invalid hour please enter a valid hour between 0 to 23")
        return
    if 5 <= hour < 12:
        greeting = "Good Morning"
    elif 12 <= hour < 17:
        greeting = "Good Afternoon"
    elif 17 <= hour < 21:
        greeting = "Good Evening"
    else:
        greeting = "Hello"
    print(f"{greeting},{username}")
greet_user("Rumisa",5)
greet_user("Ayesha",14)
greet_user("Husna",18)
greet_user("Rumana",0)

