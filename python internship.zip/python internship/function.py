list = [1,2,3]
list.append(4)
print (list)

list = [1,2,3]
list.sort()
print(list)

list=[1,2,3]
list.sort(reverse=True)
list.reverse
print(list)

list=[1,2,3,4]
list.insert(2,4)
print(list)

list=[1,2,3,4,5]
list.remove(3)
print(list)


list = ["apple","banana","cherry"]
list.append("water")
list.append("orange")
print(list)

list = ["apple","banana","cherry"]
list.remove("cherry")
print(list)

list = ["apple","banana","cherry"]
list.sort()
print(list)

print(f"remaining tasks for sunday evening in bhakarapet: ")
for task in list:
    print(task)
    
    
evening_tasks = ["charge phone","read a book","prepare for tomorrow"]
print("initial tasks:{evening_tasks}")
evening_tasks.append("Drink milk")
print(f"after appending:{evening_tasks}")
evening_tasks.insert(0,"call parents")
print(f"after inserting at start:{evening_tasks}")
evening_tasks.remove("read a book")
print(f"after removing a task:{evening_tasks}")
evening_tasks.sort()
print(f"sorted tasks:{evening_tasks}")
task_count = len(evening_tasks)
print(f"\n You have {task_count}task left to do")



favorite_movies = []
for i in range(1, 4):
    movie = input(f"Enter the name of favorite movie #{i}: ")
    favorite_movies.append(movie)
print("Your favorite movies are:", favorite_movies)
