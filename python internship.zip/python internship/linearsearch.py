def linear_search(arr, target):
    for index, value in enumerate(arr):
        if value == target:
            return index  
    return -1  


my_list = [5, 3, 8, 4, 2]
target_value = 4

result = linear_search(my_list, target_value)
if result != -1:
    print(f"Target {target_value} found at index {result}.")
else:
    print(f"Target {target_value} not found in the list.")
