##
stack = [10, 20, 30]  
print(len(stack))    

###push
stack = []
def push(item):
    stack.append(item)
    print(f"pushed: {item}")
    print(f"current stack: {stack}")
push(10)
push("hello")
push(True)

###pop

stack = []
stack.append(10)
stack.append(20)
stack.append(30)
print("Initial Stack:", stack)
popped_element = stack.pop()
print("Popped Element:", popped_element)
print("Stack after pop:", stack)



###peek
stack = []
stack.append(10)
stack.append(20)
stack.append(30)
print("Stack:", stack)
if stack: 
    top_element = stack[-1]
    print("Top element (peek):", top_element)
else:
    print("Stack is empty")


###isempty
stack = []
def is_empty(stack):
    return len(stack) == 0
stack.append(10)
stack.append(20)
print("Stack:", stack)
if is_empty(stack):
    print("Stack is empty")
else:
    print("Stack is not empty")
stack.pop()
stack.pop()
if is_empty(stack):
    print("Stack is empty")
else:
    print("Stack is not empty")
    
    
class BrowserHistory:
    def __init__(self, homepage: str):
        self.history = [homepage]  # Stores visited pages, current page is at the top
        self.future = []           # Stores pages for forward navigation

    def visit(self, url: str) -> None:
        self.history.append(url)
        self.future = []  # Clear forward history when a new page is visited

    def back(self, steps: int) -> str:
        while steps > 0 and len(self.history) > 1:
            self.future.append(self.history.pop())
            steps -= 1
        return self.history[-1]

    def forward(self, steps: int) -> str:
        while steps > 0 and self.future:
            self.history.append(self.future.pop())
            steps -= 1
        return self.history[-1]

# Example Usage:
browser = BrowserHistory("homepage.com")
browser.visit("google.com")
browser.visit("facebook.com")
print(f"Current page after visiting: {browser.history[-1]}")

browser.back(1)
print(f"Current page after 1 back: {browser.history[-1]}")

browser.visit("youtube.com") # Visiting a new page clears forward history
print(f"Current page after visiting YouTube: {browser.history[-1]}")

browser.back(1)
print(f"Current page after 1 back: {browser.history[-1]}")

browser.forward(1)
print(f"Current page after 1 forward: {browser.history[-1]}")



###create a two empty stack one is for google history another one is for future history
google_history = []
future_history = []
google_history.append("How to learn Python")
google_history.append("Python stack implementation")
google_history.append("Google stock price")
future_history.append("Learn machine learning")
future_history.append("Travel to bangalore")
future_history.append("Start a new project")
print("Google History Stack:")
print(google_history) 
print("\nFuture History Stack:")
print(future_history)
if google_history:
    print("\nMost recent Google search:", google_history[-1])
if google_history:
    popped_search = google_history.pop()
    print("Popped from Google History:", popped_search)
    print("Google History after pop:", google_history)