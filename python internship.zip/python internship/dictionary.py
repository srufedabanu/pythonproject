dict = {1 : "moon" , 2 : "start" , 3 : "roze"}
print(dict)

user_profile = {"name": "Hanzala", "age": 12 ,"is_active": True}
print(user_profile)     
print(f"The type of our variable is:{type(user_profile)}")

student_data = {
    "name":"hanzala",
    "marks":{ 
        "python":80,
        "english":95,
        "java":85
    }
}
print(student_data["marks"]["python"])

dict = {1 : "moon" , 2 : "start" , 3 : "roze"}
for key in dict.keys():
    print(f"{key}")

dict = {1 : "moon" , 2 : "start" , 3 : "roze"}
for value in dict.values():
    print(f"{value}")

dict ={1 : "moon" , 2 : "start" , 3 : "roze"}
for key , value in dict.items():
    print(f"{key}:{value}")
dict.items()
print(dict)

dict ={1 : "moon" , 2 : "start" , 3 : "roze"}
for get in dict.get(key):
    print(f"{get}")
    
    
dict = {1 : "moon" , 2 : "start" , 3 : "roze"}
new_Dict = {4 : "for" , 5 : "hii" , 6 : "hello"}
dict.update(new_Dict)
for key , value in dict.items():
    print(f"{key}:{value}")
    
    
dict = {1 : "moon" , 2 : "start" , 3 : "roze"}
removed_value = dict.pop(2)
print(removed_value)
print(dict)



dict = {1 : "moon" , 2 : "start" , 3 : "roze"}
last_item = dict.popitem()
print(last_item)
print(dict)


dictionary = {
    "table" : "a piece of furniture list of facts and figures",
    "cat" : "a small animal"
}
print(dictionary["table"])
print(dictionary["cat"])

marks_dict = {}

subjects = [
    "english",
    "kanada",
    "science"
]
for subject in subjects:
    marks = int(input(f"enter marks for {subject}:"))
    marks_dict[subject] = marks
print("marks entered:",marks_dict)


suqares = {num :num**2 for num in range(1,11)}
print(suqares)

bengaluru_pincode = {
    "Koramangala": 560034,
    "Indiranagar": 560038,
    "Jayanagar": 560041,
    "MG Road": 560001,
    "Whitefield": 560066,
    "Malleshwaram": 560003,
    "Rajajinagar": 560010,
    "Basavanagudi": 560004,
    "Electronic City": 560100,
    "Hebbal": 560024
}

area = "Indiranagar"
print(f"Pincode for {area} is {bengaluru_pincode.get(area, 'Area not found')}")


vehicle_counts = {
    "car": 0,
    "bus": 0,
    "motorcycle": 0,
    "truck": 0,
    "bicycle": 0
}

print("Enter the type of vehicle you see (car, bus, motorcycle, truck, bicycle). Type 'stop' to end.")

while True:
    vehicle = input("Vehicle: ").lower()
    
    if vehicle == "stop":
        break
    
    if vehicle in vehicle_counts:
        vehicle_counts[vehicle] += 1
        print(f"Updated count: {vehicle} = {vehicle_counts[vehicle]}")
    else:
        print("Unknown vehicle type. Please enter a valid type.")

print("\nFinal vehicle counts:")
for v_type, count in vehicle_counts.items():
    print(f"{v_type.capitalize()}: {count}")
    
    



tables = {
    1: "available",
    2: "available",
    3: "available",
    4: "available",
    5: "available"
}

def display_tables():
    print("\nCurrent Table Statuses:")
    for table, status in tables.items():
        print(f"Table {table}: {status}")

def update_table_status():
    try:
        table_number = int(input("Enter table number to update (1-5): "))
        if table_number not in tables:
            print("Invalid table number. Please try again.")
            return
        print("Select new status:")
        print("1. available")
        print("2. occupied")
        print("3. reserved")
        status_choice = input("Enter choice (1/2/3): ")
        status_map = {"1": "available", "2": "occupied", "3": "reserved"}
        if status_choice not in status_map:
            print("Invalid status choice.")
            return
        tables[table_number] = status_map[status_choice]
        print(f"Table {table_number} status updated to {status_map[status_choice]}.")
    except ValueError:
        print("Please enter a valid number.")

def main():
    print("Welcome to Koramangala Restaurant Table Management")
    while True:
        display_tables()
        print("\nOptions:")
        print("1. Update Table Status")
        print("2. Exit")
        choice = input("Enter your choice: ")
        if choice == "1":
            update_table_status()
        elif choice == "2":
            print("Exiting system. Have a good day!")
            break
        else:
            print("Invalid choice. Please select again.")

if __name__ == "__main__":
    main()

