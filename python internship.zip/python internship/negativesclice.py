text="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
part1 = text[14:-12]
part2 = text[-3:-1]
part3 = text[-1]
part4 = text[:3]
print(part1)
print(part2)
print(part3)
print(part4)