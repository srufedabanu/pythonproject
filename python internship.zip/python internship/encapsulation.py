class BankAccount:
    def __init__(self,balance):
        self._balance = balance
    def deposite(self,amount):
        if amount > 0:
            self._balance += amount
        else:
            print("Deposite must be positive.")
    def get_balance(self):
        return self._balance
account = BankAccount(5000)
account.deposite(1000)
print("Balance:",account.get_balance())
print(account._balance)

class Student:
    def __init__(self,name,marks):
        self.name = name
        self.__marks = marks
        
    def get_marks(self):
       return self.__marks
   
    def set_marks(self,marks):
       if 0 <= marks <= 100:
           self.__marks = marks
       else:
           print("Marks should be between 0 and 100.")
s = Student("Ayesha",85)
print("Name:",s.name)
print("Marks:",s.get_marks())
s.set_marks(95)
print("Update marks:",s.get_marks())

#multilevel inheritance
class Animal:
        def __init__(self,species):
            self.species = species
        def show_species(self):
            print(f"Species: {self.species}")
class Mammal(Animal):
    def __init__(self, species,has_fur):
        super().__init__(species)
        self.has_fur = has_fur
        
    def show_Mammal_info(self):
        fur_status = "has fur" if self.has_fur else "does not have fur"
        print(f"This mammal: {fur_status}")
        
class Dog(Mammal):
    def __init__(self, species, has_fur,breed):
        super().__init__(species, has_fur)
        self.breed = breed
        
    def show_breed(self):
        print(f"Breed: {self.breed}")
        
dog = Dog("Canine", True, "Golden Retriever")
dog.show_species()
dog.show_Mammal_info()
dog.show_breed()
            
#multiple inheritance
#First parent class
class Flyer:
    def fly(self):
        print("Flying high!")
#second parent class
class Swimmer:
    def swim(self):
        print("Swimming deep!")
#child class inherit from both flyer and swimmer
class Duck(Flyer,Swimmer):      
    def quack(self):
        print("Quack quack!")
#create an object
donald = Duck()
donald.fly()
donald.swim()
donald.quack()

#hierachial inheritence
class Animal:
    def __init__(self,name):
        self.name = name
    def eat(self):
        print(f"{self.name} is eating!")
class Dog(Animal):
    def bark(self):
        print(f"{self.name} is barking!")
class Cat(Animal):
    def meow(self):
        print(f"{self.name} is meowing!")
dog = Dog("Buddy")
cat = Cat("whiskers")

dog.eat()
dog.bark()

cat.eat()
cat.meow()

#hybrid inheritance
class Person:
    def details(self):
        print("Person details")
class Student(Person):
    def study(self):
        print("Student is studying")
class Teacher(Person):
    def teach(self):
        print("Teacher is teaching")
class TeachingAssistant(Student, Teacher):
    def assist(self):
        print("Teaching Assistant is assisting")
ta = TeachingAssistant()
ta.details()  
ta.study() 
ta.teach()   
ta.assist()

