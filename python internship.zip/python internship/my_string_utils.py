string1 = 'hello'
string2 = "python"
string3 = '''welcome'''

print(string1)
print(string2)
print(string3)


    
# genrating random password
    
import random
import string
def generate_password(length=12):
    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(random.choice(characters) for _ in range(length))
    return password
print("Generated Password:", generate_password(12))

import string
import secrets
def generate_password(length=12):
    if length < 4:
        raise ValueError("Password length should be at least 4 characters.")
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    symbols = string.punctuation
    password = [
        secrets.choice(lowercase),
        secrets.choice(uppercase),
        secrets.choice(digits),
        secrets.choice(symbols),
    ]
    all_chars = lowercase + uppercase + digits + symbols
    password += [secrets.choice(all_chars) for _ in range(length - 4)]
    secrets.SystemRandom().shuffle(password)
    return ''.join(password)
print("Generated password:", generate_password(16))