set = {10,22,35,45,45,54,22,66,76,66}
print(set)

set = {10,22,35,45,45,54,22,66,76,66}
set.add(38)
print(set)

set = {10,22,35,45,45,54,22,66,76,66}
set.remove(45)
print(set)

set= {10,22,35,45,45,54,22,66,76,66}
set.clear()
print(set)

set = {10,22,35,45,45,54,22,66,76,66}
set.pop()
print(set)
