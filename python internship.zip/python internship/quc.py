departure_times = [18,19,20,21,22,23]
current_time = 20
buses_after_8pm = []
for time in departure_times:
     if time > current_time:
         buses_after_8pm.append(time)
print("Buses leaving after 8 pm:")
print(buses_after_8pm)

bus_schedule = [18, 19, 20, 21, 22]
current_hour = 20
print(f"Checking for buses after {current_hour}:00...")
for departure_time in bus_schedule:
    if departure_time > current_hour or departure_time == current_hour:
        print(f"Bus departs at {departure_time}:00")


appliances_data = [
    ["Ceiling Fan", 75, 8],
    ["LED Tv", 80, 5],
    ["Fridge", 200, 6],
    ["LED Bulbs", 40, 7]
]
cost_per_unit_kwh = 7.50
total_kwh_per_month = 0
for appliance in appliances_data:
    power_walts = appliance[1]
    daily_hours = appliance[2]
    monthly_kwh = (power_walts * daily_hours*30)/1000
    total_kwh_per_month += monthly_kwh
    total_bill = total_kwh_per_month * cost_per_unit_kwh
    print("***Total Estimated Electricity Bill***")
    print(f"Total kWh used per month: {total_kwh_per_month:.2f} kWh")
    print(f"Total electricity bill: ₹{total_bill:.2f}")
   
