###create a array 
num = [1,2,3,4,5,6,7,8]
print(num)
print(type(num))


###create a array using list and append the value and call the function
def make_array_and_append(values):
    arr = []           
    for v in values:
        arr.append(v) 
    return arr
result = make_array_and_append([10, 20, 30])
print(result)  


###create a function findind the maximum value array call the maximum value
def find_max(arr):
    if not arr:
        raise ValueError("Empty list provided")
    maximum = arr[0]
    for num in arr[1:]:
        if num > maximum:
            maximum = num
    return maximum
my_list = [4, 2, 7, 20]
my_list.append(10)      
print(find_max(my_list)) 

###
def find_max(arr):
   return max(arr)  
values = [5, 8, 1]
values.append(12)
print(find_max(values))



###create one array find the odd numbers square the odd number
numbers = [1,2,3,4,5,6,7,8,9,10]
odd_squares = []
for num in numbers:
    if num % 2 != 0:
        odd_squares.append(num ** 2)
print("Squared odd numbers:",odd_squares)


 ###create a array and create a target and using for loop create two sum pair and using function
def two_sum_bruteforce(nums, target):
    n = len(nums)
    for i in range(n):
        for j in range(i + 1, n):
            if nums[i] + nums[j] == target:
                return nums[i], nums[j]
    return None


numbers = [2, 7, 11, 15]
target = 9
result = two_sum_bruteforce(numbers, target)
print("Pair found:" , result)