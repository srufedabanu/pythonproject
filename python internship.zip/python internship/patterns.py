rows = 5
for i in range(1, rows + 1):
    print("*" * i)


rows = 5
for i in range(1, rows + 1):
    print(str(i) * i)
