##print the n numbers ss while simultenously storing them in a set and find sum of n natural numbers
n = 10
natural_numbers = set()
sum_of_numbers = 0
for i in range(1, n + 1):
    print(i)
    natural_numbers.add(i)
    sum_of_numbers += i
print(f"Sum of first {n} natural numbers: {sum_of_numbers}")

##
n=10
sum_of_numbers = n*(n+1)//2
print(f"Sum of first {n} natural numbers: {sum_of_numbers}")


##create a two sets to find even and odd numbers
n = 20
even_numbers = set()
odd_numbers = set()
for i in range(1, n + 1):
    if i % 2 == 0:
        even_numbers.add(i)
    else:
        odd_numbers.add(i)
print(f"Even numbers from 1 to {n}: {even_numbers}")


##a small tea stall owner in a village ran a speacial offer today and noted down the mobile number of every customer who visited available it .how many customers visited the stall today
customer_mobile_numbers = [
    "9876543210",
    "9876543211",
    "9876543212",
    "9876543210",  # Duplicate
    "9876543213",
    "9876543214",
]
total_customers = len(customer_mobile_numbers)
unique_customers = len(set(customer_mobile_numbers))
print(f"Total customers who visited the stall today: {total_customers}")
print(f"Total unique customers who visited the stall today: {unique_customers}")

##two friends , ram and vamsi , want to find out which hobbies they have in common so they can do them together.
ram_hobbies = {"reading", "gaming", "hiking", "cooking"}
vamsi_hobbies = {"gaming", "cooking", "painting", "cycling"}
common_hobbies = ram_hobbies & vamsi_hobbies
print(f"Ram's hobbies: {ram_hobbies}")
print(f"Vamsi's hobbies: {vamsi_hobbies}")
print(f"Common hobbies : {common_hobbies}")



##for the upcoming vinayaka chavithi festival in tirupati, two volunteers were registering guests at different entrances. to avoid confusion and print a final guest list , you need 
##to consolidate their list , your task is to identify guest who mistakenly registered at both desks , find the unique guest from each desk, and generate a final, alphabetized list of
#all unique attendees

def consolidate_guest_lists(desk1, desk2):
    # Convert lists to sets for easy operations
    set1 = set(desk1)
    set2 = set(desk2)

    # Find duplicates (common guests)
    duplicates = sorted(set1 & set2)

    # Combine unique guests and common guests into one sorted list
    final_guest_list = sorted(set1 | set2)

    return duplicates, final_guest_list


# Input guest registrations at each desk
desk1_registration = ["Anil", "Bharath", "Chaitanya", "Deepika", "Eshwar"]
desk2_registration = ["Chaitanya", "Deepika", "Feroz", "Gowtham", "Hema"]

# Call the function
duplicates, final_guest_list = consolidate_guest_lists(desk1_registration, desk2_registration)

# Output
print(f"guests who registered at both desks: {duplicates}")
print(f"final alphabetized guest list: {final_guest_list}")

def calculate_average_marks(student_data):
    student_marks = {}
    student_marrks_count = {}
    proceessed_students = set()
    for name, mark in student_data:
        if name not in proceessed_students:
            student_marks[name] = mark
            student_marrks_count[name] = 1
            proceessed_students.add(name)
        else:
            student_marks[name] += mark
            student_marrks_count[name] += 1
    average_marks = {name: marks / student_marrks_count[name] for name, marks in student_marks.items()}
    return average_marks

## Example usage
if __name__ == "__main__":
    student_data = [
        ("heena", 85),
        ("tassu", 90),
        ("heena", 95),
        ("tassu", 80),
        ("yassu", 70)
    ]
    average_marks = calculate_average_marks(student_data)
print(average_marks)
    
    
    

student_data = [
        ("heena", 85),
        ("tassu", 90),
        ("heena", 95),
        ("tassu", 80),
        ("yassu", 70)
    ]
marks_by_student = {}
for name, mark in student_data:
    if name not in marks_by_student:
        marks_by_student[name] = []
    marks_by_student[name].append(mark)
    for name, marks in marks_by_student.items():
        average_mark = sum(marks) / len(marks)
        print(f"{name}: {average_mark:.2f}")
        
        
        
        

##find the set of words that appear in both texts
##find the set of words that are unique to the first text
##return the total number of unique words across both texts

def analyze_texts(text1, text2):
    words1 = set(text1.split())
    words2 = set(text2.split())
    
    common_words = words1 & words2
    unique_to_text1 = words1 - words2

    total_unique_words = len(words1 | words2)
    
    return common_words, unique_to_text1, total_unique_words

text1 = "python is a great programming language"
text2 = "many developers love python language"

common_words, unique_to_text1, total_unique_words = analyze_texts(text1, text2)
print(f"words common to both texts: {common_words}")
print(f"words unique to the first text: {unique_to_text1}")
print(f"total number of unique words across both texts: {total_unique_words}")


##find the set of words that appear in both texts
##find the set of words that are unique to the first text
##return the total number of unique words across both texts

def analyze_texts(text1, text2):
    words1 = set(text1.split())
    words2 = set(text2.split())
    
    common_words = words1 & words2
    unique_to_text1 = words1 - words2

    total_unique_words = len(words1 | words2)
    
    return common_words, unique_to_text1, total_unique_words

text1 = "python is a great programming language"
text2 = "many developers love python language"

common_words, unique_to_text1, total_unique_words = analyze_texts(text1, text2)
print(f"words common to both texts: {common_words}")
print(f"words unique to the first text: {unique_to_text1}")
print(f"total number of unique words across both texts: {total_unique_words}")



###
text1 = "python is a great programming language"
text2 = "many developers love python language"
words1 =set(text1.lower().split())
words2 = set(text2.lower().split())
common_words = words1 & words2
print(common_words)
print("-"*50)
unique_to_text1 = words1 - words2
print(unique_to_text1)
print("-"*50)
total_unique_words = len(words1 | words2)
print(total_unique_words)
print("-"*50)

