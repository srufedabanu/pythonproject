class Dog:
    def make_sound(self):
        print("The dog barks.")
class Cat:
    def make_sound(self):
        print("The cat meow.")
my_dog = Dog()
my_cat = Cat()

animals = [my_dog,my_cat]
for animal in animals:
    animal.make_sound()
    
class Addition:
    def __init__(self,num1,num2):
        self.num1 = num1
        self.num2 = num2
    def add(self):
        return self.num1 + self.num2
add = Addition(3,5)
print(f"Addtion of num1 and num2 is :{add.add()}")

class Book:
    def __init__(self,title,pages):
        self.title = title
        self.pages = pages
    def __str__(self):
        """Controls what print() shows"""
        return f"{self.title}({self.pages}pages)"
    def __len__(self):
        """controls what len() does."""
        return self.pages
    def __add__(self,other_book):
        """controls what the '+' operator does."""
        return self.pages + other_book.pages
book1 = Book("The Hobbit",295)
book2 = Book("The Fellowship of the ring",423)

print(book1)
print(len(book2))
print(book1 + book2)




class Wallet:
    def __init__(self,amount):
        self.amount = amount
    def __add__(self,other_wallet):
        total_amount = self.amount + other_wallet.amount
        return Wallet(total_amount)
    def __str__(self):
        return f"Wallet with ${self.amount}"
wallet1 = Wallet(500)
wallet2 = Wallet(800)

combined_wallet = wallet1 + wallet2
print(combined_wallet)

class SavingsAccount:
    def deposit(self, amount):
        print(f"Savings Account: Deposited ₹{amount}")

    def withdraw(self, amount):
        print(f"Savings Account: Withdrew ₹{amount}")

class CurrentAccount:
    def deposit(self, amount):
        print(f"Current Account: Deposited ₹{amount}")

    def withdraw(self, amount):
        print(f"Current Account: Withdrew ₹{amount}")

def perform_transaction(account, amount):
    account.deposit(amount)
    account.withdraw(amount)

savings = SavingsAccount()
current = CurrentAccount()

perform_transaction(savings, 1000)
perform_transaction(current, 2000)


class Vehical:
    def start(self):
        print("vehical starting!")
class Car(Vehical):
    def start(self):
        print("car starting")
        super().start()
car = Car()
car.start()

class Brid:
    def fly(self):
        print("brid can fly.")
class Airplane:
    def fly(self):
        print("Airplance can fly!.")
def lets_fly(flaying_object):
    flaying_object.fly()
brid = Brid()
plane = Airplane()
lets_fly(brid)
lets_fly(plane)
