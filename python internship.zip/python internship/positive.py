text = "ayesha"
part1 = text[1]
part2 = text[4]
print("first part:",part1)
print("second part:",part2)