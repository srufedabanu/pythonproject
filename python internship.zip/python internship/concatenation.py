name = "ayesha"
roll_no = "101"
result = "student name : " + name + "| roll number : " + roll_no
print(result)
