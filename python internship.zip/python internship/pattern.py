s = "hello"
s.find('l',2)
s.find('l', 1,2)
s.find('l',2,3)