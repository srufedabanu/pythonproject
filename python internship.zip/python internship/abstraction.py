class Animal:
    def __init__(self,name):
        self.name = name
        
    def make_sound(self):
        raise NotImplementedError("Subclasses must implement the make_sound() method.")
    
class Dog(Animal):
    def make_sound(self):
        return "Woof!"
    
class Cat(Animal):
    def make_sound(self):
        return "Meow!"
    
#creating objects
my_dog = Dog("Buddy")
my_cat = Cat("whiskers")

print(f"{my_dog.name} says :{my_dog.make_sound()}")
print(f"{my_cat.name} says :{my_cat.make_sound()}")

import random
num = random.randint(1 , 10)
print("Random number:",num)

import random
num = random.randint(1 , 100)
print("Random number:",num)

import random
count = 5
for i in range(1, count+1):
    num = random.randint(1,100)
    print(f"Try {i}: Random Number is {num}")
    
    
    
    import random

def guess_the_number_game():
    secret_number = random.randint(1,10)
    guess = None
    attempts = 0
    
    print("--- Welcome to guess the number! ---")
    print("I have picked a number between 1 and 10")
    print("Can you guess what it is?")
    
    while guess != secret_number:
        try:
            guess_input = input("Enter your guess: ")
            guess = int(guess_input)
            attempts += 1
            
            if guess < secret_number:
                print("Too low! Try guessing higher.")
            elif guess > secret_number:
                print("Too high! Try guessing lower.")
            else:
                print(f"\nCongratulations! You guessed the number correctly!")
                print(f"The secret number was {secret_number}.")
                print(f"It took you {attempts} attempts to guess.")
        except ValueError:
            print("Invalid input. Please enter a number.")

if __name__ == "__main__":
    guess_the_number_game()


import random

def guess_the_number_game():
    secret_number = random.randint(1, 10)
    guess = None
    attempts = 0

    print("--- Welcome to guess the number! ---")
    print("I have picked a number between 1 and 10")
    print("Can you guess what it is?")

    while guess != secret_number:
        try:
            guess_input = input("Enter your guess: ")
            guess = int(guess_input)
            attempts += 1

            if guess < secret_number:
                pass  # no print here
            elif guess > secret_number:
                pass  # no print here
            # if equal, loop ends automatically
        except ValueError:
            print("Invalid input. Please enter a number.")

    # After correct guess:
    print(f"\nCongratulations! You guessed the number correctly!")
    print(f"The secret number was {secret_number}.")
    print(f"It took you {attempts} attempts to guess.")

if __name__ == "__main__":
    guess_the_number_game()
