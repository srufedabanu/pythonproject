
    
for i in range(1,101):
    print(i)
    
for i in range(100,0,-1):
    print(i)
        

def multiplication_table(n):
    for i in range(1,11):
        print(f"{n} x {i} = {n*i}")
n=5
multiplication_table(n)

