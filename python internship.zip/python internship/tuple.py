x=(2,1,3,1)
target=3

for i in x:
    if i == target:
        print("target:",i)
        index=x.index(target)
        print("index target:",index)