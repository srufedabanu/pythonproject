def add(x,y):
    return x + y
print(add(2,3))

add_lambda  = lambda x ,y:x +y
print(add_lambda(2,3))

def sort_by_second_element(tuples_list):
    return sorted(tuples_list, key=lambda x: x[1])

data = [(1,3),(4,1),(4,2)]
sorted_data = sort_by_second_element(data)
print(sorted_data)

# Lambda functions for arithmetic operations
add = lambda x, y: x + y
subtract = lambda x, y: x - y
multiply = lambda x, y: x * y
divide = lambda x, y: x / y if y != 0 else "Error: Division by zero"

a, b = 10, 5

print(f"Add: {a} + {b} = {add(a, b)}")
print(f"Subtract: {a} - {b} = {subtract(a, b)}")
print(f"Multiply: {a} * {b} = {multiply(a, b)}")
print(f"Divide: {a} / {b} = {divide(a, b)}")


create_dict = lambda key, value: {key: value}
my_dict = create_dict("name", "Alice")
print(my_dict)  

