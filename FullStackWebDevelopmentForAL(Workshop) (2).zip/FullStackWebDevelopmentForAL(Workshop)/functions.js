
function greet(name){
    return "Hello, " + name + "!"
}

res=greet("Ayesha"); // calling the function
alert(res);


function add (a,b){
    return a + b;
}

// function expression for use in html file

const findMax=function(a,b){
    return a > b ? a : b;
}

document.write("The maximum of 10 and 20 is : " + findMax(10,20));

//Arrow function
const multiply = (x,y)=> x * y;
document.write("<br>The product of 5 and 4 is:" + multiply(4,5));